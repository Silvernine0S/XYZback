              ZBACK MANUAL README
              ===================

This help file - "Zback User's Manual" - is a user contribution, created by
Allen Titley.  Please read the INSTALLATION and POSSIBLE ISSUES sections below
before using.

NOTE
----
The Manual contains Jscript (Javascript) code to enable rollover images, and a
few instances of ActiveX calls which can open Windows components (such as
"Regional and Language Options") as a convenience to the user.
      ** BOTH JSCRIPT AND ACTIVEX, AS USED HERE, ARE COMPLETELY SAFE! **
See "POSSIBLE ISSUES" below for more comments.


+-------------+
| A. FEATURES |
+-------------+
  o  can be opened from within Zback (press F2 key); the original (smaller) 
     "Zback User's Guide" can be opened using the F1 key (see INSTALLATION).
  o  context-sensitive opening from Zback, depending on which tab is in use.
  o  provides a complete Zback reference, with examples of usage, etc.
  o  fast page navigation using image 'hot spots' - click 'Interface' on the
     manual's toolbar to start.
  o  Contents tab, Index tab and (full text) Search tab for navigation.
  o  Favorites tab to save links to frequently used pages.


+-----------------+
| B. INSTALLATION |
+-----------------+
Unzip the manual and make sure the file ("zmanual.chm") is in the same folder
as "zback.exe".  This folder should also contain "zguide.chm" (the User's
Guide) and other support files for Zback from it's installation.
When you open Zback next time, on Help panel [Manual F2] button should appear.


THIS SECTION MAY APPLY IF YOU ARE UNABLE TO VIEW A CHM FILE PROPERLY.
+--------------------+
| C. POSSIBLE ISSUES |
+--------------------+
The 2 CHM files for Zback - "zmanual.chm" and "zguide.chm" - are compiled HTML
Help files, the same format used by many of Windows' own help files.  Both
files should open without a problem (either by double-clicking on the file, or
through Zback's F1, F2 method).  However, there are possible issues which might
prevent the files from displaying properly.

1.  SECURITY issue:
------------------
Modern versions of Windows consider compiled HTML files (i.e. CHM) to be a
potential risk, since they 'might' contain both Jscript and ActiveX components
which could have "malicious intent".  As a result, Windows may BLOCK the file
resulting in the following behaviour:
  - file opens, showing table of contents, but right pane (page content) is
    either blank (empty!) or displays the message:
        "Navigation to the webpage was canceled".
    This is true for EVERY page; your system has flagged the file as coming
    from a potentially 'untrusted source'.

>>FIX:
From within Explorer or from your own file manager (e.g. Total Commander,
XYplorer, etc.) do the following simple tasks:
  a) Right-click on "zmanual.chm" (or "zguide.chm") and click Properties on the
     context menu.
  b) On the General tab, you 'may' see (at the bottom) the following:
          This file came from another             +-----------+
          computer and might be blocked to        |  Unblock  |
          help protect this computer.             +-----------+
     If this message is visible, click "Unblock".  The help file should now
     function properly.
     Note: you may need administrative privileges in order to use "Unblock".
See the following Internet link for an sample image, and more information:
     http://www.xyplorer.com/faq-topic.php?id=chm

2.  PATH NAME issue:
-------------------
If the path to a CHM help file contains the "#" character (i.e. hash character)
ANYWHERE in the path, Windows cannot open the help file properly.  Each page
may display the message:
     "The page cannot be displayed"
Example path:  C:\Program Files\Tools#1\Zback\zmanual.chm
THIS PATH WILL NOT WORK!
This is a known issue with all(?) modern versions of Windows and relates to the
fact that the hash character (#) is used in HTML as an anchor (i.e. bookmark)
and is misinterpreted by the HTML parser when it appears in a path.

>>FIX:
Rename the 'offending' folder to avoid the hash (#) character, as in:
     C:\Program Files\Tools_1\Zback\zmanual.chm (from example path above)
Renaming may affect other files already in a folder on the affected path.

3.  FILE LOCATION issue:
-----------------------
Windows may block CHM files that are housed on mapped network drives.

>>FIX:
Move the file (and Zback.exe, etc.) to a local drive on your computer.
See the Internet link at the end of issue 1. for more information.
For detailed technical information on this issue, see Microsoft Knowledge Base
article 896054 at:
     http://support.microsoft.com/kb/896054

______________________________________________________________________________
******************************************************************************

I hope this User's Manual is useful to you!  Zback is an excellent tool and is
worthy of the effort involved in creating the Manual.  If you have any comments
or suggestions about the help file, please contact me by email.

- Allen Titley
  British Columbia, Canada
  email: atbcls@shaw.ca

And remember the old saying: "When all else fails - read the instructions!"
